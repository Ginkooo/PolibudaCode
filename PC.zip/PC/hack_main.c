#include <targets/AT91SAM7.h> //Dołączenie pliku nagłówkowego AT91SAM7.h z bibliotek systemowych
#include "usart.h" //Dołączenie pliku nagłówkowego usart.h znajdującego się w folderze z projektem
#include "lcd.h" //Dołączenie pliku nagłówkowego lcd.h znajdującego się w folderze z projektem

#define SW_LEWY PIOA_SODR_P7 //Zdefiniowanie nazwy dla portu 7 (joystick w lewo)
#define SW_DOL PIOA_SODR_P8 //Zdefiniowanie nazwy dla portu 8 (joystick w dół)
#define SW_GORA PIOA_SODR_P9 //Zdefiniowanie nazwy dla portu 9 (joystick w górę)
#define SW_PRAWY PIOA_SODR_P14 //Zdefiniowanie nazwy dla portu 14 (joystick w prawo)
#define SW_NACISK PIOA_SODR_P15 //Zdefiniowanie nazwy dla portu 15 (wciśnięcie joysticka)

void delay(int n)  __attribute__ ((section(".fast"))); //Przekazanie procedury opóźnienia do pamięci RAM

void delay(int n) //Procedura opóźnienia
{
  volatile int i; //Deklaracja zmiennej swobodnej

  for(i = 3000 * n; i > 0; i--)
  {
    __asm__("nop"); //Makroinstrukcja NOP (no operation), trwa 1 cykl zegara
  }
}

int main()
{
  PMC_PCER = PMC_PCER_PIOB | PMC_PCER_PIOA; //Włączenie kontrolera PIO

  InitUSART0(); //Inicjalizacja USART0
  InitLCD(); //Inicjalizacja LCD
  LCDSettings(); //Ustawienie LCD
  LCDClearScreen(); //Wyczyszczenie ekranu

  while(1) //Pętla nieskończona
  {
    if((PIOA_PDSR & SW_NACISK) == 0) //Jeśli joystick jest wciśnięty
    { 
      write_str_USART0("x"); //Przesłanie do komputera znaku "x"
      delay(500); //Opóźnienie
    }

    if((PIOA_PDSR & SW_DOL) == 0) //Jeśli przycisk joystick w dół jest wciśnięty
    { 
      write_str_USART0("d"); //Przesłanie do komputera znaku "d"
      delay(500); //Opóźnienie
    }

    if((PIOA_PDSR & SW_PRAWY) == 0) //Jeśli przycisk joystick w prawo jest wciśnięty
    { 
      write_str_USART0("p"); //Przesłanie do komputera znaku "p"
      delay(500); //Opóźnienie
    }

    if((PIOA_PDSR & SW_LEWY) == 0) //Jeśli przycisk joystick w lewo jest wciśnięty
    { 
      write_str_USART0("l"); //Przesłanie do komputera znaku "l"
      delay(500); //Opóźnienie
    }

    if((PIOA_PDSR & SW_GORA) == 0) //Jeśli przycisk joystick w górę jest wciśnięty
    { 
      write_str_USART0("g"); //Przesłanie do komputera znaku "g"
      delay(500); //Opóźnienie
    }

    char znak = read_char_USART0_nonstop(); //Odbieranie danych z komputera bez przerwy i zapisywanie do zmiennej "znak"

    if(znak == 'x') //Jeśli odebrano znak "x"
    {
      LCDPutStr("wcisniety", 20, 20, LARGE, WHITE, BLACK); //Wyświetlenie na ekranie tekstu "wcisniety"
    }

    if(znak == 'g') //Jeśli odebrano znak "g"
    {
      LCDPutStr("gora     ", 20, 20, LARGE, WHITE, BLACK); //Wyświetlenie na ekranie tekstu "gora"
    }

    if(znak == 'd') //Jeśli odebrano znak "d"
    {
      LCDPutStr("dol      ", 20, 20, LARGE, WHITE, BLACK); //Wyświetlenie na ekranie tekstu "dol"
    }

    if(znak == 'l') //Jeśli odebrano znak "l"
    {
      LCDPutStr("lewo     ", 20, 20, LARGE, WHITE, BLACK); //Wyświetlenie na ekranie tekstu "lewo"
    }

    if(znak == 'p') //Jeśli odebrano znak "p"
    {
      LCDPutStr("prawo    ", 20, 20, LARGE, WHITE, BLACK); //Wyświetlenie na ekranie tekstu "prawo"
    }
  }

  return 0;
}