#include <targets/AT91SAM7.h>
#include "usart.h"
#include "lcd.h"

#define SW_LEFT PIOA_SODR_P7
#define SW_BOTTOM PIOA_SODR_P8
#define SW_UP PIOA_SODR_P9
#define SW_RIGHT PIOA_SODR_P14
#define SW_PUSH PIOA_SODR_P15

#define SW_1 PIOB_SODR_P24
#define SW_2 PIOB_SODR_P25

__attribute__ ((section(".fast")));
void delay(int n)
{
  volatile int i;

  for(i = 3000 * n; i > 0; i--)
  {
    __asm__("nop");
  }
}

int len = 0;
int* pos;

void initialize() {
	PMC_PCER = PMC_PCER_PIOB | PMC_PCER_PIOA;
	InitUSART0();
	InitLCD();
	LCDSettings();
	LCDClearScreen(); 
}

int* calculate_pos(int len) {
	int ret[2];

	ret[0] = 10;
	ret[1] = 10;
	
	return ret;
}

void write_and_wait(char* str) {
	write_str_USART0(str);
	delay(250);
}

int main() {
	initialize();
	unsigned char input = 0;

	char outstr[20];
	for (;;) {
		input = read_char_USART0_nonstop();
		if (!(PIOB_PDSR & SW_1)) {
			write_and_wait("Wcisnieto: 1");
		}
		if (!(PIOB_PDSR & SW_2)) {
			write_and_wait("Wcisnieto: 2");
		}
		if (!(PIOA_PDSR & SW_BOTTOM)) {
			write_and_wait("Dol");
		}
        if (!(PIOA_PDSR & SW_UP)) {
			write_and_wait("Gora");
		}
        if (!(PIOA_PDSR & SW_LEFT)) {
			write_and_wait("Lewo");
		}
        if (!(PIOA_PDSR & SW_RIGHT)) {
			write_and_wait("Prawo");
		}
        if (!(PIOA_PDSR & SW_PUSH)) {
			write_and_wait("Wcisniecie");
		}

		if (input) {
			sprintf(outstr, "%c\0", input);
			len++;
			pos = calculate_pos(len);
			LCDPutStr(' ', pos[0], pos[1], LARGE, WHITE, BLACK);
			LCDPutStr(outstr, pos[0], pos[1], LARGE, WHITE, BLACK);
		}
	}
	
}