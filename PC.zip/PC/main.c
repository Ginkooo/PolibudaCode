#include <targets/AT91SAM7.h>
#include "adc.h"
#include "lcd.h"

#define AUDIO_OUT PIOB_SODR_P19
#define SW_1 PIOB_SODR_P24
#define SW_2 PIOB_SODR_P25

__attribute__ ((section(".fast")));

void delay(int n) {
  volatile int i;

  for(i=3000*n; i>0; --i) {
    __asm__("nop");
  }
}

void prepare_lcd() {
  InitLCD();
  InitADC();
  LCDSettings();
  LCDClearScreen();
}

void prepare_registers() {
  PMC_PCER = PMC_PCER_PIOB | PMC_PCER_PIOA | PMC_PCER_ADC;
  PIOB_OER = AUDIO_OUT;
  PIOB_PER = AUDIO_OUT;
  ADC_CR = ADC_CR_SWRST;
  ADC_CHER = ADC_CHER_CH6;
  ADC_MR = (23<<ADC_MR_PRESCAL_BIT) | (2<<ADC_MR_STARTUP_BIT) |
  (1<<ADC_MR_SHTIM_BIT);
}

void put_temp(char* outstr, char* unit, float value, float y) {
    int out, a, b;
    value = value * 100;
    out = (int)value;
    a = out/100;
    b = out % 100;
    
    sprintf(outstr, "%s: %d.%d   \0", unit, a, b);
    if (a < 26) LCDPutStr(outstr, y, 10, LARGE, BLUE, BLACK);
    else if (a < 30) LCDPutStr(outstr, y, 10, LARGE, WHITE, BLACK);
    else LCDPutStr(outstr, y, 10, LARGE, RED, BLACK);
}

int main() {
  prepare_registers();
  int out;
  float degrees, fahrenheit, kelvin;
  char* outstr;
  prepare_lcd();
  while(1) {
    ADC_CR = ADC_CR_START;
    out = GetAdcChanel(ADC_CHN_6);

    degrees = ((out-565)/3.57) + 24.;
    fahrenheit = degrees * 9/5 + 32;
    kelvin = degrees + 273.15;

    char buffer[7];

    put_temp(buffer, "C", degrees, 100);
  }
}