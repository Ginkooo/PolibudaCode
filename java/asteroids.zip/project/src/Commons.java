/**
 * Created by ginko on 27.04.17.
 */
public class Commons {
    public static final int HEIGHT = 600;
    public static final int WIDTH = 600;
    public static final int window_x = 10;
    public static final int window_y = 10;
    public static final int SHIP_ROT_SPEED = 8;
    public static final int SHIP_SPEED = 6;
    public static final int ASTEROID_DELAY = 100;
    public static final int MAX_ASTEROID_SPEED = 4;
}
