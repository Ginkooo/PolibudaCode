#include <avr/io.h>
#include <util/delay.h>

ex1() {
	PORTA = 0b10000000;
	while (PORTA > 0b00000000) {
		_delay_ms(500);
		PORTA >>= 1;
	}
	PORTA = 0b00000001;
	while (PORTA > 0b00000000) {
		_delay_ms(1000);
		PORTA <<=1;
	}
}

ex2() {
	PORTA = 0b10000000;
	while (PORTA < 0b11111111) {
		_delay_ms(500);
		PORTA >>=1;
		PORTA += 0b10000000;
	}
	while (PORTA > 0b00000000) {
		_delay_ms(1000);
		PORTA <<=1;
	}
}

ex3() {
	int i;
	int right = 0b00000001;
	int left = 0b10000000;
	for (i=0; i<4; i++) {
		_delay_ms(500);
		PORTA = right | left;
		left >>= 1;
		left |= 0b10000000;
		right <<= 1;
		right += 1;
	}

	for (i=0; i<5; i++) {
		_delay_ms(500);	
		left <<= 1;
		right >>= 1;
		PORTA = right | left;
	}
}

int main() {
	for(;;) {
		DDRA = 0xff;
		ex1();
		ex2();
		ex3();
	}
}
